import time
from time import sleep
from lxml import html
from scraper import WebDriver
import elastic as el
import logging
from argparse import ArgumentParser

parser = ArgumentParser()
parser.add_argument("-f", "--file", dest="filename",
                    help="import new products from file", metavar="FILE")
parser.add_argument("-s", "--scrape", help="start scrapping to discover new reviews, "
                                           "switch to the next asin once we find review "
                                           "we already have in our DB", action='store_true')
parser.add_argument("-a", "--all", help="scrape all to the end of pagination pages nomatter we have them in DB or not", action='store_true')
parser.add_argument("-hd", "--notheadless", help="first run will make scrapper indexing all reviews", action='store_true')
args = parser.parse_args()

logging.basicConfig(level=logging.INFO, filename='app.log', filemode='a',
                    format='%(asctime)s - %(name)s - %(levelname)s- %(filename)s- %(funcName)s - %(message)s')
logging.getLogger().addHandler(logging.StreamHandler())

settings = el.settings

def import_asins(file):
    with open(file, 'r') as file:
        asin = None
        for product in file:
            if "http" in product:
                parts = product.split("/")
                asin = parts[parts.index("dp") + 1].strip()
            elif len(product.strip()) == 10:
                asin = product.strip()
            if len(asin) != 10:
                asin = None

            if asin:
                if not el.asin_exist(asin):
                    print("importing {}".format(asin))
                    el.add_asin(asin, {'asin': asin})
                else:
                    print("asin  {} already exist".format(asin))


def xpath(dom, path):
    try:
        return dom.find(path).text_content().strip()
    except:
        return ''


def process_page(dom, url, asin):
    logging.info("processing page {}".format(url))
    sel = settings["review_selectors"]
    reviews = dom.xpath(sel["container"])
    for r in reviews:
        doc_id = r.xpath(sel["id"])[0]
        stars = xpath(r, sel["stars"]).split("von")
        review_exists = el.review_exist(doc_id)
        if review_exists and not args.all:
            return True
        if doc_id and not review_exists:
            doc = {
                'url': url,
                'asin': asin,
                'product_title': xpath(dom, sel["product_title"]),
                'date': xpath(r, sel["date"]),
                'stars': stars[0] if stars else '',
                'name': xpath(r, sel["name"]),
                'title': xpath(r, sel["title"]),
                'body': xpath(r, sel["body"]),
                'is_processed': False
            }
            el.add_review(doc_id, doc)
            logging.info(doc)
    return False


def start_scraping():
    review_base_url = settings["review_base_url"]
    plist = settings["proxy_list"]
    block_footprints = settings["block_footprints"]
    driver = WebDriver(proxy_list=plist, block_footprints=block_footprints, headless=not args.notheadless)
    for asin in el.get_asins():
        try:
            asin = asin["_source"]["asin"]
            sleep(settings["requests_interval"])
            page_num = 0
            while True:
                page_num += 1
                url = review_base_url.format(asin, page_num)
                driver.get(url)
                page = driver.get_source()

                dom = html.fromstring(page)
                if driver.is_blocked():
                    driver.quit()
                    logging.error(
                        "ip blocked. Creating new driver instance {} -- {} -- {}".format(driver.proxy, page_num, url))
                    driver = WebDriver(proxy_list=plist, block_footprints=block_footprints,  headless=not args.notheadless)
                    break
                not_process_next = process_page(dom, url, asin)
                if not_process_next:
                    break
                if dom.xpath(settings["pagination_finished_sel"]) \
                        or settings["pagination_finished_text"] in page:
                    logging.info("{0} finished pagination".format(url))
                    break
                sleep(settings["requests_interval"])
        except Exception as e:
            driver.quit()
            logging.error("There was a problem processing asin {}, exception: {}"
                          .format(asin, e))
    driver.quit()


if args.filename:
    import_asins(args.filename)
    exit(0)

if args.scrape:
    start_scraping()




