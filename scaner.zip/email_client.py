import smtplib, ssl
from time import sleep
import sys
import elastic as el
import logging

logging.basicConfig(level=logging.INFO, filename='app.log', filemode='a',
                    format='%(asctime)s - %(name)s - %(levelname)s- %(filename)s- %(funcName)s - %(message)s')
logging.getLogger().addHandler(logging.StreamHandler())

email = el.settings["email"]
port = email["port"]
smtp_server = email["smtp_server"]
sender_email = sys.argv[2] if sys.argv[2] else email["sender_email"]
receiver_email =sys.argv[1] if sys.argv[1] else  email["receiver_email"]
password = sys.argv[3] if sys.argv[3] else email["password"]

for review in el.get_not_processed_reviews()[:int(email["batch_amount"])]:
    try:
        doc = review["_source"]
        print(doc)
        message = email["message_template"].encode('utf-8')
        message = message % (bytes(doc["product_title"],encoding='utf8'), bytes(doc["name"],encoding='utf8'),
                         bytes(doc["title"],encoding='utf8'),
                         bytes(doc["body"],encoding='utf8'),
                         bytes(doc["stars"],encoding='utf8'),
                         bytes(doc["url"],encoding='utf8'))
        context = ssl.create_default_context()
        with smtplib.SMTP(smtp_server, port) as server:
            server.ehlo()  # Can be omitted
            server.starttls(context=context)
            server.ehlo()  # Can be omitted
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message)
            el.set_processed(review["_id"])
            logging.info("Sending email  for review{}".format(review["_id"], ''))
            sleep(email["send_interval"])

    except Exception as e:
        el.set_processed(review["_id"], False)
        logging.error("There was a problem sending email for product {}, exception: {}".format(review["_id"], e))
