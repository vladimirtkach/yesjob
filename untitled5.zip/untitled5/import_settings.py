from datetime import datetime

from elasticsearch import Elasticsearch

es = Elasticsearch()
settings = {
    'email': {
        'message_template': """Subject: Review for: %b

            You have new review from %b:
             %b 
             %b 
            With %b stars
            Check it here %b
        """,
        'port': 587,
        'smtp_server': "smtp.gmail.com",
        'sender_email': "log@seo-day.de",
        'receiver_email': "vovatkach75@gmail.com",
        'password': 'sday2011+4711',
        'send_interval': 3,
    },
    'review_selectors': {
        'container': './/div[@id="cm_cr-review_list"]/div[@data-hook="review"]',
        'id': '@id',
        'stars': './/i[@data-hook="review-star-rating"]',
        'name': './/span[@class="a-profile-name"]',
        'title': './/a[@data-hook="review-title"]/span',
        'body': './/span[@data-hook="review-body"]',
        'date': './/span[@data-hook="review-date"]',
        'product_title': './/h1/a[@data-hook="product-link"]',

    },
    'review_base_url': "https://www.amazon.de/product-reviews/{0}/?ie=UTF8&reviewerType=all_reviews&pageNumber={1}&sortBy=recent",
    'requests_interval': 3,
    'proxy_list': ['socks5://127.0.0.1:9050'],
    'block_footprints': ['Weitere Informationen über die Migration zu unseren APIs finden'],
    'pagination_finished_sel': './/li[@class="a-disabled a-last"]',
    'pagination_finished_text': "Leider stimmen keine Rezensionen mit ihrer derzeitiger Auswahl überein",

}

es.index(index="reviews-index-settings", doc_type='settings', id=1, body=settings)
settings = es.get(index="reviews-index-settings", doc_type='settings', id=1)["_source"]
print(settings)
