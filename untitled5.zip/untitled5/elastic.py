from datetime import datetime

from elasticsearch import Elasticsearch
from elasticsearch.exceptions import NotFoundError

es = Elasticsearch()
settings = es.get(index="reviews-index-settings", doc_type='settings', id=1)["_source"]

def set_processed(doc_id, state=True):
    es.update(index="reviews-index", doc_type='review',
              id=doc_id, body={"doc": {'is_processed': state}})


def get_not_processed_reviews():
    return es.search(index="reviews-index", size=100,
                     body={"query": {'term': {'is_processed': False}}})["hits"]["hits"]


def review_exist(doc_id):
    try:
        es.get(index="reviews-index", doc_type='review', id=doc_id)
        return True
    except NotFoundError:
        return False


def add_review(doc_id, review):
    es.index(index="reviews-index", doc_type='review', id=doc_id, body=review)


def asin_exist(asin):
    try:
        es.get(index="asins-index", doc_type='asin', id=asin)
        return True
    except NotFoundError:
        return False


def add_asin(asin, asin_body):
    es.index(index="asins-index", doc_type='asin', id=asin, body=asin_body)


def get_asins():
    return es.search(index="asins-index", size=1000,
                     body={"query": {'match_all': {}}})["hits"]["hits"]

