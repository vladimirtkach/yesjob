import smtplib, ssl
from time import sleep

import elastic as el
import logging

logging.basicConfig(level=logging.ERROR, filename='app.log', filemode='a',
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

email = el.settings["email"]
port = email["port"]
smtp_server = email["smtp_server"]
sender_email = email["sender_email"]
receiver_email = email["receiver_email"]
password = email["password"]


for review in el.get_not_processed_reviews():
    try:
        sleep(email["send_interval"])
        doc = review["_source"]
        print(doc)
        message = email["message_template"].encode('utf-8')
        message = message % (bytes(doc["product_title"],encoding='utf8'), bytes(doc["name"],encoding='utf8'),
                         bytes(doc["title"],encoding='utf8'),
                         bytes(doc["body"],encoding='utf8'),
                         bytes(doc["stars"],encoding='utf8'),
                         bytes(doc["url"],encoding='utf8'))
        context = ssl.create_default_context()
        with smtplib.SMTP(smtp_server, port) as server:
            server.ehlo()  # Can be omitted
            server.starttls(context=context)
            server.ehlo()  # Can be omitted
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message)
            el.set_processed(review["_id"])
    except Exception as e:
        el.set_processed(review["_id"], False)
        logging.error("There was a problem sending email for product {}, exception: {}".format(review["_id"], e))
