import time
from time import sleep
from lxml import html
from scraper import WebDriver
import elastic as el
import logging
from argparse import ArgumentParser

parser = ArgumentParser()
parser.add_argument("-f", "--file", dest="filename",
                    help="import new products from file", metavar="FILE")
parser.add_argument("-s", "--scrape", action='store_true')
args = parser.parse_args()

logging.basicConfig(level=logging.ERROR, filename='app.log', filemode='a',
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

settings = el.settings



def import_asins(file):
    with open(file, 'r') as file:
        asin = None
        for product in file:
            if "http" in product:
                parts = product.split("/")
                asin = parts[parts.index("dp") + 1].strip()
            elif len(product.strip()) == 10:
                asin = product.strip()
            if len(asin) != 10:
                asin = None

            if asin:
                if not el.asin_exist(asin):
                    print("importing {}".format(asin))
                    el.add_asin(asin, {'asin': asin})
                else:
                    print("asin  {} already exist".format(asin))


def xpath(dom, path):
    try:
        return dom.find(path).text_content().strip()
    except:
        return ''


def process_page(dom, url, asin):
    sel = settings["review_selectors"]
    reviews = dom.xpath(sel["container"])
    for r in reviews:
        doc_id = r.xpath(sel["id"])[0]
        stars = xpath(r, sel["stars"]).split("von")
        if doc_id and not el.review_exist(doc_id):
            doc = {
                'url': url,
                'asin': asin,
                'product_title': xpath(dom, sel["product_title"]),
                'date': xpath(r, sel["date"]),
                'stars': stars[0] if stars else '',
                'name': xpath(r, sel["name"]),
                'title': xpath(r, sel["title"]),
                'body': xpath(r, sel["body"]),
                'is_processed': False
            }
            el.add_review(doc_id, doc)
            logging.info(doc)


def start_scraping():
    review_base_url = settings["review_base_url"]
    plist = settings["proxy_list"]
    block_footprints = settings["block_footprints"]
    driver = WebDriver(proxy_list=plist, block_footprints=block_footprints)
    for asin in el.get_asins():
        try:
            asin = asin["_source"]["asin"]
            sleep(settings["requests_interval"])
            page_num = 0
            while True:
                page_num += 1
                url = review_base_url.format(asin, page_num)
                driver.get(url)
                page = driver.get_source()

                dom = html.fromstring(page)
                if driver.is_blocked():
                    driver.quit()
                    logging.error(
                        "ip blocked. Creating new driver instance {} -- {} -- {}".format(driver.proxy, page_num, url))
                    driver = WebDriver(proxy_list=plist, block_footprints=block_footprints)
                    break
                process_page(dom, url, asin)

                if dom.xpath(settings["pagination_finished_sel"]) \
                        or settings["pagination_finished_text"] in page:
                    logging.info("{0} finished pagination".format(url))
                    break
                sleep(settings["requests_interval"])
        except Exception as e:
            logging.error("There was a problem processing asin {}, exception: {}"
                          .format(asin, e))


if args.filename:
    import_asins(args.filename)
    exit(0)

if args.scrape:
    start_scraping()




